#define HEADS 20
#define SECTORS 17
#define CYLINDERS 160 
